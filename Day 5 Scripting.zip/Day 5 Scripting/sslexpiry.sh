#!/bin/bash

domain="guvi.in"
cert_info=$(openssl s_client -connect $domain:443 -servername $domain -showcerts </dev/null 2>/dev/null | openssl x509 -text)
expiration_date=$(echo "$cert_info" | grep "Not After" | awk -F ':' '{print $2 $3 $4}')
expiration_timestamp=$(date -d "$expiration_date" +%s)
current_timestamp=$(date +%s)
remaining_days=$(( ($expiration_timestamp - $current_timestamp) / (60*60*24) ))
echo "SSL certificate for $domain will expire in $remaining_days days."


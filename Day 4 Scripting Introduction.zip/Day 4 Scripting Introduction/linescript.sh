#!/bin/bash

# Input file
filename="givtolearn.txt"

# Using awk and regex to replace occurrences of "give" with "learning" from the 5th line onwards for lines holding welcome alone
awk '/welcome/ && NR >= 5 { gsub(/give/, "learning"); } 1' $filename > temp_file && mv temp_file $filename

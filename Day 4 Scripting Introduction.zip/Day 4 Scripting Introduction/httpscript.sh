#!/bin/bash

url="https://guvi.in"
response=$(curl -s -o /dev/null -w "%{response}" $url)
if [ $response -eq 301 ]; then
  echo "Success and HTTP response: $response"
else
  echo "Failure and HTTP response: $response"
fi
